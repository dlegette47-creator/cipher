import React, { useState, useEffect } from "react";
import { Lock, Fingerprint, ChevronLeft, DownloadCloud, AtSign, Camera, RefreshCw, KeyRound, Check } from "lucide-react";
import { useChatStore } from "./store/chatStore";
import { uploadToBlossom } from '@nostr-wot/blossom';

export default function LockScreen({ identity }) {
  const [mode, setMode] = useState(() => {
    try {
      return (localStorage.getItem('cipher_vault') || localStorage.getItem('cipher_vaults')) ? 'unlock' : 'create';
    } catch (e) { return 'create'; }
  }); // create, unlock, restore, restore_mnemonic, setup_profile
  const [handle, setHandle] = useState('');
  const [pin, setPin] = useState('');
  const [mnemonic, setMnemonic] = useState('');
  const [error, setError] = useState('');
  const [enableBio, setEnableBio] = useState(false);
  const [savedMnemonic, setSavedMnemonic] = useState('');
  const [mnemonicConfirmed, setMnemonicConfirmed] = useState(false);
  const [verifyIndices, setVerifyIndices] = useState([]);
  const [verifyInputs, setVerifyInputs] = useState(['', '', '']);
  const [verifyError, setVerifyError] = useState('');
  const [loading, setLoading] = useState(false);

  const [tempIdentity, setTempIdentity] = useState(null);
  const [username, setUsername] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [avatar, setAvatar] = useState(null);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);

  useEffect(() => {
    if (identity.hasBiometric && mode === 'unlock') handleBiometric();
  }, [identity.hasBiometric, mode]);

  const handleBiometric = async () => {
    setLoading(true);
    const res = await identity.unlockWithBiometric();
    if (!res.success) setError('Biometrics failed. Use your PIN.');
    setLoading(false);
  };

  const checkUsernameAvailable = async (username) => {
    try {
      const { SimplePool } = await import('nostr-tools');
      const pool = new SimplePool();
      const relays = ['wss://relay.primal.net', 'wss://groups.aegispayhq.com', 'wss://nos.lol'];
      const events = await Promise.race([
        pool.querySync(relays, { kinds: [10003], '#t': ['cipher_username_' + username], limit: 5 }),
        new Promise(r => setTimeout(() => r([{ id: 'timeout', tags: [] }]), 3000)),
      ]);
      return events.length === 0;
    } catch (e) {
      console.warn('Precheck failed — failing CLOSED to prevent squatting:', e);
      return false; // audit H14: fail closed, not open
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true); setError('');

    const cleanHandle = handle.toLowerCase().trim().replace(/[^a-z0-9_]/g, '');
    if (mode === 'create' || mode === 'restore') {
      if (cleanHandle.length < 3) { setError('Handle must be at least 3 letters/numbers'); setLoading(false); return; }
    }
    if (mode !== 'restore_mnemonic' && pin.length < 4) { 
      setError('PIN must be at least 4 digits'); 
      setLoading(false); 
      return; 
    }

    try {
      if (mode === 'create') {
        const available = await checkUsernameAvailable(cleanHandle);
        if (!available) {
          setError('@' + cleanHandle + ' is already taken. Try another.');
          setLoading(false);
          return;
        }
        const res = await identity.createVault(cleanHandle, pin, enableBio);
        setTempIdentity(res);
        setUsername(cleanHandle);
        setDisplayName(cleanHandle);
        const _words = (res.mnemonic || '').split(' ');
        const _idxs = [];
        while (_idxs.length < 3) {
          const r = Math.floor(Math.random() * _words.length);
          if (!_idxs.includes(r)) _idxs.push(r);
        }
        setVerifyIndices(_idxs);
        setVerifyInputs(['', '', '']);
        setVerifyError('');
        setSavedMnemonic(res.mnemonic || '');
        setMnemonicConfirmed(false);
        setMode('save_key');
      } else if (mode === 'unlock') {
        const res = await identity.unlock(pin);
        if (!res.success) setError(res.error || 'Invalid PIN');
      } else if (mode === 'restore') {
        const res = await identity.restoreFromRelays(cleanHandle, pin);
        if (!res.success) setError(res.error);
      } else if (mode === 'restore_mnemonic') {
        if (!mnemonic.trim() || mnemonic.trim().split(/\s+/).length < 12) {
          setError('Please enter your full 12-word phrase');
        } else {
          const res = await identity.restoreFromMnemonic(mnemonic, pin);
          if (!res.success) setError(res.error);
        }
      }
    } catch (err) {
      setError(err?.message || 'Something went wrong');
    }
    setLoading(false);
  };

  const handleAvatarUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file || !tempIdentity) return;
    setUploadingAvatar(true);
    try {
      const blob = await uploadToBlossom(file, {
        signer: {
          getPublicKey: async () => tempIdentity.pk,
          signEvent: async (event) => {
            const { finalizeEvent } = await import('nostr-tools');
            return finalizeEvent(event, tempIdentity.sk);
          }
        },
      });
      setAvatar(blob.url);
    } catch (err) { 
      useChatStore.getState().setToast({ type: 'info', message: 'Upload failed: ' + err.message }); 
    } finally { 
      setUploadingAvatar(false); 
    }
  };

  const handleSaveKeyContinue = (e) => {
    e.preventDefault();
    if (!mnemonicConfirmed) return;
    setMode('verify_key');
  };

  const handleVerifyKey = (e) => {
    e.preventDefault();
    const words = savedMnemonic.split(' ');
    const allCorrect = verifyIndices.every((idx, i) =>
      verifyInputs[i].trim().toLowerCase() === (words[idx] || '').toLowerCase()
    );
    if (!allCorrect) {
      setVerifyError('Some words are incorrect. Go back and check your phrase.');
      return;
    }
    setVerifyError('');
    setMode('setup_profile');
  };

  const handleFinishSetup = async (e) => {
    e.preventDefault();
    const clean = username.replace('@', '').trim().toLowerCase();
    if (clean.length < 3) return setError('Username must be 3+ characters');
    if (!/^[a-z0-9_]+$/.test(clean)) return setError('Only letters, numbers, underscores');
    setLoading(true);
    
    localStorage.setItem('cipher_new_account', 'true'); // Trigger tutorial
    await identity.finalizeLogin(tempIdentity.sk, tempIdentity.pk, tempIdentity.npub, {
      username: clean,
      displayName: displayName.trim() || clean,
      picture: avatar
    });
    setLoading(false);
  };

  const isMnemonicMode = mode === 'restore_mnemonic';

  return (
    <div className="w-full h-[100dvh] overflow-y-auto bg-black flex flex-col items-center justify-center px-6 py-12 relative">
      
      {/* Subtle top glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-md h-64 bg-blue-500/10 blur-[100px] pointer-events-none"></div>

      <div className="relative z-10 w-full max-w-sm flex flex-col items-center">
        
        {/* Logo */}
        <img 
          src="/icon-192.png" 
          alt="Cipher" 
          className="w-28 h-28 object-contain mb-6 drop-shadow-[0_0_30px_rgba(59,130,246,0.3)]" 
        />

        {/* Header */}
        <h1 className="text-3xl font-bold tracking-tight text-white mb-2 text-center">
          {mode === 'verify_key' ? 'Verify Your Recovery Key' : mode === 'save_key' ? 'Save Your Recovery Key' : mode === 'setup_profile' ? 'Your Profile' : mode === 'create' ? 'Welcome to Cipher' : mode === 'unlock' ? 'Enter PIN' : mode === 'restore' ? 'Restore Account' : 'Recovery Phrase'}
        </h1>
        <p className="text-gray-400 text-[15px] text-center mb-8 max-w-[280px] leading-relaxed">
          {mode === 'verify_key' ? 'Enter the words below to confirm you saved the phrase.' : mode === 'save_key' ? 'Write down these 12 words. You need them + your PIN to recover this account.' : mode === 'setup_profile' ? 'Let people know who you are.' 
           : mode === 'create' ? 'Pick a handle and a PIN (4+ digits).' 
           : mode === 'unlock' ? 'Enter your PIN to unlock.' 
           : mode === 'restore' ? 'Enter your handle and PIN.'
           : 'Enter your 12-word phrase and a new PIN.'}
        </p>

        {/* Glass Card Form */}
        <form onSubmit={mode === 'verify_key' ? handleVerifyKey : mode === 'save_key' ? handleSaveKeyContinue : mode === 'setup_profile' ? handleFinishSetup : handleSubmit} className="w-full flex flex-col bg-[#0a0a0a]/80 backdrop-blur-2xl border border-white/10 p-6 rounded-3xl shadow-2xl">
          
          {mode === 'save_key' ? (
            <div className="space-y-6 w-full">
              <div className="grid grid-cols-3 gap-2 w-full">
                {(savedMnemonic || '').split(' ').map((word, i) => (
                  <div key={i} className="bg-[#0f0f0f] border border-white/10 rounded-lg p-2.5 text-center text-[13px] text-white font-mono">
                    {word}
                  </div>
                ))}
              </div>
              <label className="flex items-center gap-3 text-gray-400 text-sm cursor-pointer hover:text-white transition-colors">
                <div className="relative flex items-center justify-center w-5 h-5">
                  <input type="checkbox" checked={mnemonicConfirmed} onChange={(e) => setMnemonicConfirmed(e.target.checked)} className="peer appearance-none w-5 h-5 border border-white/20 rounded-md checked:bg-blue-500 checked:border-blue-500 transition-colors cursor-pointer" />
                  <Check size={14} className="absolute text-white pointer-events-none opacity-0 peer-checked:opacity-100 transition-opacity" strokeWidth={3} />
                </div>
                I have written down these 12 words.
              </label>
            </div>
          ) : mode === 'setup_profile' ? (
            <>
              <div className="relative mb-6 group cursor-pointer mx-auto">
                <div className="w-24 h-24 rounded-full bg-[#0f0f0f] border-2 border-dashed border-white/20 flex items-center justify-center overflow-hidden transition-all group-hover:border-blue-500/50">
                  {avatar ? (
                    <img src={avatar} alt="avatar" className="w-full h-full object-cover" />
                  ) : (
                    <Camera size={28} className="text-gray-500 group-hover:text-blue-400 transition-colors" />
                  )}
                </div>
                <input type="file" accept="image/*" onChange={handleAvatarUpload} className="absolute inset-0 opacity-0 cursor-pointer" />
                {uploadingAvatar && <div className="absolute inset-0 bg-black/60 flex items-center justify-center rounded-full"><RefreshCw size={20} className="animate-spin text-white" /></div>}
              </div>

              <input 
                type="text" 
                placeholder="Display Name (optional)"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="w-full bg-[#0f0f0f] border border-white/10 rounded-xl px-5 py-4 text-[16px] text-white placeholder-gray-600 focus:outline-none focus:border-blue-500 focus:ring-0 transition-all mb-4"
              />
              
              <div className="w-full relative mb-6">
                <AtSign size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" />
                <input
                  type="text"
                  placeholder="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ''))}
                  className="w-full bg-[#0f0f0f] border border-white/10 rounded-xl pl-11 pr-5 py-4 text-[16px] text-white placeholder-gray-600 focus:outline-none focus:border-blue-500 focus:ring-0 transition-all"
                />
              </div>
            </>
          ) : (
            <>
              {mode === 'verify_key' && (
                <div className="space-y-3 mb-6">
                  <div className="text-center mb-4">
                    <p className="text-sm text-gray-400">Enter words #{verifyIndices.map(i => i + 1).join(', #')} from your recovery phrase</p>
                  </div>
                  {verifyIndices.map((idx, i) => (
                    <div key={idx} className="w-full relative">
                      <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 font-mono text-sm pointer-events-none">Word #{idx + 1}</span>
                      <input
                        type="text"
                        placeholder="..."
                        value={verifyInputs[i] || ''}
                        onChange={(e) => {
                          const newInputs = [...verifyInputs];
                          newInputs[i] = e.target.value.toLowerCase().trim();
                          setVerifyInputs(newInputs);
                          setVerifyError('');
                        }}
                        className="w-full bg-[#0f0f0f] border border-white/10 rounded-xl pl-24 pr-5 py-4 text-[16px] text-white placeholder-gray-600 focus:outline-none focus:border-blue-500 transition-all font-mono"
                        autoCapitalize="none"
                        autoCorrect="off"
                        spellCheck="false"
                      />
                    </div>
                  ))}
                  {verifyError && <p className="text-red-500 text-xs text-center mt-2">{verifyError}</p>}
                </div>
              )}

              {isMnemonicMode && (
                <textarea
                  placeholder="apple banana cherry ..."
                  value={mnemonic}
                  onChange={(e) => { setMnemonic(e.target.value); setError('') }}
                  className="w-full bg-[#0f0f0f] border border-white/10 rounded-xl p-5 text-[15px] text-white placeholder-gray-600 focus:outline-none focus:border-blue-500 focus:ring-0 transition-all mb-4 h-28 resize-none font-mono"
                  autoCapitalize="none"
                  autoCorrect="off"
                  spellCheck="false"
                />
              )}

              {(mode === 'create' || mode === 'restore') && (
                <div className="w-full relative mb-4">
                  <AtSign size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" />
                  <input
                    type="text"
                    placeholder="yourhandle"
                    value={handle}
                    onChange={(e) => { setHandle(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, '')); setError('') }}
                    className="w-full bg-[#0f0f0f] border border-white/10 rounded-xl pl-11 pr-5 py-4 text-[16px] text-white placeholder-gray-600 focus:outline-none focus:border-blue-500 focus:ring-0 transition-all"
                  />
                </div>
              )}

              {!isMnemonicMode && mode !== 'verify_key' && (
                <input
                  type="password"
                  placeholder="PIN (4+ digits)"
                  value={pin}
                  onChange={(e) => { setPin(e.target.value.replace(/\D/g, '').slice(0, 8)); setError('') }}
                  className="w-full bg-[#0f0f0f] border border-white/10 rounded-xl px-5 py-4 text-[16px] text-white placeholder-gray-600 focus:outline-none focus:border-blue-500 focus:ring-0 transition-all tracking-[0.5em] text-center mb-4"
                  maxLength={8}
                />
              )}

              {mode === 'create' && (
                <label className="flex items-center justify-center gap-3 text-gray-400 text-sm mt-2 mb-2 cursor-pointer hover:text-white transition-colors">
                  <div className="relative flex items-center justify-center w-5 h-5">
                    <input type="checkbox" checked={enableBio} onChange={(e) => setEnableBio(e.target.checked)} className="peer appearance-none w-5 h-5 border border-white/20 rounded-md checked:bg-blue-500 checked:border-blue-500 transition-colors cursor-pointer" />
                    <Check size={14} className="absolute text-white pointer-events-none opacity-0 peer-checked:opacity-100 transition-opacity" strokeWidth={3} />
                  </div>
                  Enable Biometric Unlock
                </label>
              )}
            </>
          )}

          {error && <p className="text-red-500 text-sm text-center mt-2 mb-2 font-medium">{error}</p>}

          <button type="submit" disabled={loading || (mode === 'save_key' && !mnemonicConfirmed) || (mode === 'verify_key' && verifyInputs.some(v => !v.trim()))} className="w-full bg-blue-600 hover:bg-blue-500 text-white font-semibold text-[16px] tracking-wide py-4 rounded-xl mt-4 shadow-[0_4px_20px_-4px_rgba(59,130,246,0.4)] transition-all active:scale-[0.98] disabled:bg-[#1a1a1a] disabled:text-gray-600 disabled:border disabled:border-white/5 disabled:shadow-none disabled:pointer-events-none flex justify-center items-center">
            {loading ? <RefreshCw size={20} className="animate-spin" /> : mode === 'verify_key' ? 'Verify & Continue' : mode === 'save_key' ? (mnemonicConfirmed ? 'Continue' : 'Confirm you saved it') : mode === 'setup_profile' ? 'Enter Cipher' : mode === 'create' ? 'Create Account' : mode === 'unlock' ? 'Unlock' : mode === 'restore' ? 'Restore Account' : 'Recover Account'}
          </button>
        </form>

        {/* Footer Links */}
        <div className="mt-8 flex flex-col items-center gap-4">
          {mode === 'unlock' && (
            <button type="button" onClick={() => { setMode('restore'); setError(''); setPin('') }} className="text-gray-500 hover:text-white text-sm font-medium transition-colors">
              Forgot PIN? Restore account
            </button>
          )}

          {mode === 'create' && (
            <div className="flex flex-col gap-4 mt-2 w-full items-center">
              <button type="button" onClick={() => { setMode('restore'); setError(''); setPin(''); }} className="text-gray-400 hover:text-white text-sm font-medium transition-colors">
                Restore account on this device
              </button>
              <button type="button" onClick={() => { setMode('restore_mnemonic'); setError(''); setPin(''); setMnemonic('') }} className="text-blue-400 hover:text-blue-300 text-sm font-medium transition-colors">
                Restore with 12-word recovery phrase
              </button>
            </div>
          )}

          {mode === 'restore' && (
            <>
              <button type="button" onClick={() => { setMode('restore_mnemonic'); setError(''); setPin(''); }} className="text-gray-500 hover:text-white text-sm font-medium transition-colors flex items-center gap-2">
                <KeyRound size={14} /> Use Recovery Phrase
              </button>
              <button type="button" onClick={() => { setMode('create'); setError(''); setPin('') }} className="text-gray-500 hover:text-white text-sm font-medium transition-colors">
                Create a new account instead
              </button>
            </>
          )}

          {mode === 'restore_mnemonic' && (
            <button type="button" onClick={() => { setMode('restore'); setError(''); setPin(''); }} className="text-gray-500 hover:text-white text-sm font-medium transition-colors flex items-center gap-2">
              <ChevronLeft size={14} /> Back to handle restore
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
