import React, { useState, useRef } from 'react';
import { Users, Megaphone, Pin, BellOff, Archive, Search, X } from 'lucide-react';
import { useChatStore } from '../../store/chatStore';
import { scopedGet } from '../../lib/storage';
import ChatContextMenu from './ChatContextMenu';

export default function ChatList({ onOpenChat }) {
  const dms = useChatStore(s => s.dms);
  const groups = useChatStore(s => s.groups);
  const groupMessages = useChatStore(s => s.groupMessages);
  const profiles = useChatStore(s => s.profiles);
  const unreadCounts = useChatStore(s => s.unreadCounts);
  const pinnedChats = useChatStore(s => s.pinnedChats);
  const archivedChats = useChatStore(s => s.archivedChats);
  const mutedUntil = useChatStore(s => s.mutedUntil);

  const [filter, setFilter] = useState('all');
  const [contextMenu, setContextMenu] = useState(null);
  const [showArchived, setShowArchived] = useState(false);
  const [searchBarValue, setSearchBarValue] = useState('');
  const [searchBarFocused, setSearchBarFocused] = useState(false);
  const searchTimerRef = useRef(null);

  const acceptedReqs = scopedGet('accepted_reqs', []);
  const blockedUsers = useChatStore(s => s.blockedUsers || []);

  const dmList = Object.entries(dms)
    .filter(([pubkey]) => acceptedReqs.includes(pubkey) && !blockedUsers.includes(pubkey))
    .map(([pubkey, msgs]) => {
      const profile = profiles[pubkey];
      const safeProfile = (profile && profile.name && !/^[0-9a-f]{8,64}$/i.test(profile.name))
        ? profile
        : { displayName: `User ${pubkey.slice(0, 4)}`, picture: null, name: pubkey.slice(0, 4) };
      return { type: 'dm', id: pubkey, lastMsg: msgs[msgs.length - 1], profile: safeProfile };
    });

  const groupList = groups.map(g => ({
    type: 'group',
    id: g.id,
    group: g,
    lastMsg: groupMessages[g.id]?.[groupMessages[g.id].length - 1]
  }));

  const chatMap = new Map();
  [...dmList, ...groupList].forEach(c => chatMap.set(c.id, c));
  const allChats = Array.from(chatMap.values());

  const filteredChats = allChats.filter(c => {
    const isArchived = archivedChats.includes(c.id);
    if (showArchived && !isArchived) return false;
    if (!showArchived && isArchived) return false;
    if (filter === 'dms' && c.type !== 'dm') return false;
    if (filter === 'groups' && (c.type !== 'group' || c.group?.isChannel)) return false;
    if (filter === 'channels' && (c.type !== 'group' || !c.group?.isChannel)) return false;
    
    // Local filter by name
    if (searchBarValue.trim().length > 0) {
      const nameToMatch = c.type === 'dm' ? c.profile?.displayName : c.group?.name;
      if (!nameToMatch?.toLowerCase().includes(searchBarValue.toLowerCase())) return false;
    }
    return true;
  }).sort((a, b) => {
    const aPinned = pinnedChats.includes(a.id) ? 1 : 0;
    const bPinned = pinnedChats.includes(b.id) ? 1 : 0;
    if (aPinned !== bPinned) return bPinned - aPinned;
    return (b.lastMsg?.timestamp || 0) - (a.lastMsg?.timestamp || 0);
  });

  const handleSearchChange = (val) => {
    setSearchBarValue(val);
  };

  const openContextMenu = (chat) => {
    setContextMenu({
      id: chat.id,
      name: chat.type === 'group' ? chat.group.name : (chat.profile?.displayName || 'Chat'),
      isGroup: chat.type === 'group'
    });
  };

  const renderSearchBar = () => (
    <div className="relative mb-3">
      <div className={`flex items-center gap-2 bg-[#111] border rounded-xl px-3 py-2 transition-colors ${searchBarFocused ? 'border-blue-500' : 'border-white/10'}`}>
        <Search size={16} className="text-white/40" />
        <input
          type="text"
          value={searchBarValue}
          onChange={(e) => handleSearchChange(e.target.value)}
          onFocus={() => setSearchBarFocused(true)}
          onBlur={() => setSearchBarFocused(false)}
          placeholder="Search messages, groups, people..."
          className="flex-1 bg-transparent text-sm text-white placeholder-white/30 outline-none"
        />
        {searchBarValue && (
          <button onClick={() => setSearchBarValue('')} className="p-1 text-white/40 hover:text-white">
            <X size={14} />
          </button>
        )}
      </div>
    </div>
  );

  const renderFilterTabs = () => (
    <div className="flex gap-2 mb-3 bg-white/5 p-1 rounded-xl">
      {['all', 'dms', 'groups', 'channels'].map(f => (
        <button
          key={f}
          onClick={() => setFilter(f)}
          className={`flex-1 py-1.5 text-xs font-bold uppercase rounded-lg transition-colors ${filter === f ? 'bg-white/10 text-white' : 'text-white/40 hover:text-white'}`}
        >
          {f}
        </button>
      ))}
    </div>
  );

  if (allChats.length === 0) {
    return (
      <>
        {renderFilterTabs()}
        {renderSearchBar()}
        <p className="text-center text-white/40 mt-10">No chats yet.</p>
      </>
    );
  }

  return (
    <>
      {archivedChats.length > 0 && (
        <button
          onClick={() => setShowArchived(!showArchived)}
          className={`w-full flex items-center justify-between p-3 mb-3 rounded-xl transition-colors ${showArchived ? 'bg-blue-600/20 border border-blue-500/40' : 'bg-[#111] border border-white/5'}`}
        >
          <div className="flex items-center gap-3">
            <Archive size={16} className="text-white/60" />
            <span className="text-sm font-semibold text-white">{showArchived ? 'Back to Chats' : 'Archived'}</span>
          </div>
          <span className="text-xs text-white/50">{archivedChats.length}</span>
        </button>
      )}

      {renderFilterTabs()}
      {renderSearchBar()}

      <div className="space-y-2">
        {filteredChats.map((chat) => {
          const isPinned = pinnedChats.includes(chat.id);
          const isMuted = mutedUntil[chat.id] && (mutedUntil[chat.id] === 'forever' || mutedUntil[chat.id] > Date.now());

          if (chat.type === 'dm') {
            const profile = chat.profile;
            return (
              <div
                key={chat.id}
                onClick={() => onOpenChat('dm', chat.id)}
                onContextMenu={(e) => { e.preventDefault(); openContextMenu(chat); }}
                onTouchStart={(e) => { e.currentTarget._touchTimer = setTimeout(() => openContextMenu(chat), 600); }}
                onTouchEnd={(e) => clearTimeout(e.currentTarget._touchTimer)}
                className="relative bg-[#0a0a0a] p-4 rounded-xl border border-white/5 active:scale-[0.98] cursor-pointer flex items-center gap-4"
              >
                {isPinned && <Pin size={12} className="absolute top-2 right-2 text-blue-400" />}
                {isMuted && <BellOff size={12} className="absolute bottom-2 right-2 text-white/30" />}
                {profile.picture ? (
                  <img src={profile.picture} className="w-12 h-12 rounded-full object-cover" alt="" />
                ) : (
                  <div className="w-12 h-12 rounded-full bg-[#171717] flex items-center justify-center font-bold">
                    {profile.displayName.charAt(0)}
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold truncate">{profile.displayName}</p>
                  <p className="text-xs text-white/50 truncate">
                    {chat.lastMsg?.data?.type === 'cipher_order' ? '📦 Order'
                      : chat.lastMsg?.data?.type === 'image' ? '🖼️ Photo'
                      : chat.lastMsg?.data?.type === 'audio' ? '🎤 Voice Note'
                      : chat.lastMsg?.data?.message || ''}
                  </p>
                </div>
                {unreadCounts[chat.id] > 0 && (
                  <div className="w-5 h-5 rounded-full bg-blue-500 flex items-center justify-center text-[10px] font-bold text-white shrink-0">
                    {unreadCounts[chat.id]}
                  </div>
                )}
              </div>
            );
          } else {
            const Icon = chat.group.isChannel ? Megaphone : Users;
            return (
              <div
                key={chat.id}
                onClick={() => onOpenChat('group', chat.id, chat.group)}
                onContextMenu={(e) => { e.preventDefault(); openContextMenu(chat); }}
                onTouchStart={(e) => { e.currentTarget._touchTimer = setTimeout(() => openContextMenu(chat), 600); }}
                onTouchEnd={(e) => clearTimeout(e.currentTarget._touchTimer)}
                className="relative bg-[#0a0a0a] p-4 rounded-xl border border-white/5 active:scale-[0.98] cursor-pointer flex items-center gap-4"
              >
                {isPinned && <Pin size={12} className="absolute top-2 right-2 text-blue-400" />}
                {isMuted && <BellOff size={12} className="absolute bottom-2 right-2 text-white/30" />}
                <div className={`w-12 h-12 rounded-full flex items-center justify-center ${chat.group.isChannel ? 'bg-purple-500/20 text-purple-400' : 'bg-blue-500/20 text-blue-400'}`}>
                  <Icon size={20} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold truncate">
                    {chat.group.name && !chat.group.name.startsWith('Group ') ? chat.group.name : 'Unnamed Group'}
                  </p>
                  <p className="text-xs text-white/50 truncate">
                    {chat.group.isChannel ? '📢 Channel' : '👥 Public Group'}
                  </p>
                </div>
                {unreadCounts[chat.id] > 0 && (
                  <div className="w-5 h-5 rounded-full bg-blue-500 flex items-center justify-center text-[10px] font-bold text-white shrink-0">
                    {unreadCounts[chat.id]}
                  </div>
                )}
              </div>
            );
          }
        })}
      </div>

      {contextMenu && (
        <ChatContextMenu
          isOpen={!!contextMenu}
          onClose={() => setContextMenu(null)}
          chatId={contextMenu.id}
          chatName={contextMenu.name}
          isGroup={contextMenu.isGroup}
        />
      )}
    </>
  );
}
