import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useChatStore } from '../../store/chatStore';
import { X, Camera, Users, Megaphone, Image as ImageIcon } from 'lucide-react';

export default function CreateGroupModal({ createGroup }) {
  const showCreateGroup = useChatStore((s) => s.showCreateGroup);
  const setShowCreateGroup = useChatStore((s) => s.setShowCreateGroup);
  const newGroupName = useChatStore((s) => s.newGroupName);
  const setNewGroupName = useChatStore((s) => s.setNewGroupName);
  const newGroupAbout = useChatStore((s) => s.newGroupAbout);
  const setNewGroupAbout = useChatStore((s) => s.setNewGroupAbout);
  const isChannel = useChatStore((s) => s.isChannel);
  const setIsChannel = useChatStore((s) => s.setIsChannel);
  const loading = useChatStore((s) => s.loading);

  const [avatarPreview, setAvatarPreview] = useState(null);
  const fileInputRef = useRef(null);

  if (!showCreateGroup) return null;

  const handleAvatarUpload = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setAvatarPreview(url);
    }
  };

  const handleClose = () => {
    setShowCreateGroup(false);
    setAvatarPreview(null);
    setNewGroupName('');
    setNewGroupAbout('');
    setIsChannel(false);
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[9999] bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center"
        onClick={handleClose}
      >
        <motion.div
          initial={{ y: '100%' }}
          animate={{ y: 0 }}
          exit={{ y: '100%' }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          onClick={(e) => e.stopPropagation()}
          className="w-full sm:max-w-md bg-[#1c1c1e] rounded-t-[2rem] sm:rounded-[2rem] shadow-2xl flex flex-col overflow-hidden border border-white/10 max-h-[92dvh]"
        >
          <div className="w-full flex justify-center pt-3 pb-1">
            <div className="w-10 h-1.5 bg-white/20 rounded-full" />
          </div>
          <div className="px-6 pb-4 pt-2 flex items-center justify-between">
            <button onClick={handleClose} className="text-white/60 hover:text-white p-1">
              <X size={22} strokeWidth={2.5} />
            </button>
            <h2 className="text-lg font-bold text-white">
              {isChannel ? 'New Channel' : 'New Group'}
            </h2>
            <div className="w-8" />
          </div>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (!newGroupName.trim()) return;
              createGroup(e);
              handleClose();
            }}
            className="px-6 pb-8 flex flex-col gap-5 overflow-y-auto flex-1"
          >
            <div className="flex justify-center -mt-2 mb-2">
              <div
                onClick={() => fileInputRef.current?.click()}
                className="relative w-24 h-24 rounded-full bg-[#2c2c2e] border-2 border-dashed border-white/20 flex items-center justify-center overflow-hidden cursor-pointer group hover:border-blue-500/50 transition-colors"
              >
                {avatarPreview ? (
                  <img src={avatarPreview} alt="avatar" className="w-full h-full object-cover" />
                ) : (
                  <div className="flex flex-col items-center text-white/40 group-hover:text-blue-400 transition-colors">
                    <Camera size={28} />
                    <span className="text-[10px] font-medium mt-1">Add Photo</span>
                  </div>
                )}
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <ImageIcon size={24} className="text-white" />
                </div>
              </div>
              <input
                type="file"
                accept="image/*"
                ref={fileInputRef}
                onChange={handleAvatarUpload}
                className="hidden"
              />
            </div>
            <div className="flex flex-col gap-3">
              <input
                type="text"
                value={newGroupName}
                onChange={(e) => setNewGroupName(e.target.value)}
                placeholder={isChannel ? 'Channel Name' : 'Group Name'}
                className="w-full bg-[#0a0a0a] border border-white/10 rounded-xl px-4 py-3.5 text-[15px] text-white placeholder-white/30 focus:outline-none focus:border-blue-500 focus:ring-0 transition-colors"
                autoFocus
              />
              <textarea
                value={newGroupAbout}
                onChange={(e) => setNewGroupAbout(e.target.value)}
                placeholder="Description (Optional)"
                rows={2}
                className="w-full bg-[#0a0a0a] border border-white/10 rounded-xl px-4 py-3.5 text-[15px] text-white placeholder-white/30 focus:outline-none focus:border-blue-500 focus:ring-0 resize-none transition-colors"
              />
            </div>
            <div className="flex items-center justify-between bg-[#0a0a0a] border border-white/10 rounded-xl p-3.5 mt-1">
              <div className="flex items-center gap-3">
                <div className={`p-1.5 rounded-lg ${isChannel ? 'bg-purple-500/20 text-purple-400' : 'bg-blue-500/20 text-blue-400'}`}>
                  {isChannel ? <Megaphone size={16} /> : <Users size={16} />}
                </div>
                <div className="flex flex-col">
                  <span className="text-sm font-semibold text-white">
                    {isChannel ? 'Channel' : 'Public Group'}
                  </span>
                  <span className="text-[11px] text-white/40">
                    {isChannel ? 'Only admins can post' : 'Everyone can chat'}
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsChannel(!isChannel)}
                className={`w-12 h-6 rounded-full p-0.5 transition-colors ${isChannel ? 'bg-purple-500' : 'bg-white/20'}`}
              >
                <motion.div
                  layout
                  transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                  className="w-5 h-5 bg-white rounded-full shadow-sm"
                  style={{ marginLeft: isChannel ? 'auto' : '0' }}
                />
              </button>
            </div>
            <button
              type="submit"
              disabled={loading || newGroupName.trim().length === 0}
              className="w-full bg-blue-600 hover:bg-blue-500 disabled:bg-white/10 disabled:text-white/30 text-white font-semibold py-3.5 rounded-xl transition-all active:scale-[0.98] mt-2 flex items-center justify-center gap-2"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                `Create ${isChannel ? 'Channel' : 'Group'}`
              )}
            </button>
          </form>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}